#ifndef i_guard
#define i_guard
#include <complex>
void ixxxxx(double p[4],double fmass,int nhel,int nsf,std::complex<double> fi[6]);
#endif
